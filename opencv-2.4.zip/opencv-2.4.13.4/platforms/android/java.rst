********
Java API
********


Java API reference (JavaDoc): external `link <http://docs.opencv.org/java/>`_.
